export default function Payment() {
    return (
      <>
      <h1>Payment</h1>
      </>
    );
  }
  