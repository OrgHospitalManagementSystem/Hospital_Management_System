export default function Admin() {
    return (
      <>
      <h1>Dashbord</h1>
      </>
    );
  }
  